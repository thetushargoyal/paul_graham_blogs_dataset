Alien Truth



|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| Alien TruthOctober 2022If there were intelligent beings elsewhere in the universe, they'd
share certain truths in common with us. The truths of mathematics
would be the same, because they're true by definition. Ditto for
the truths of physics; the mass of a carbon atom would be the same
on their planet. But I think we'd share other truths with aliens
besides the truths of math and physics, and that it would be
worthwhile to think about what these might be.For example, I think we'd share the principle that a controlled
experiment testing some hypothesis entitles us to have proportionally
increased belief in it. It seems fairly likely, too, that it would
be true for aliens that one can get better at something by practicing.
We'd probably share Occam's razor. There doesn't seem anything
specifically human about any of these ideas.We can only guess, of course. We can't say for sure what forms
intelligent life might take. Nor is it my goal here to explore that
question, interesting though it is. The point of the idea of alien
truth is not that it gives us a way to speculate about what forms
intelligent life might take, but that it gives us a threshold, or
more precisely a target, for truth. If you're trying to find the
most general truths short of those of math or physics, then presumably
they'll be those we'd share in common with other forms of intelligent
life.Alien truth will work best as a heuristic if we err on the side of
generosity. If an idea might plausibly be relevant to aliens, that's
enough. Justice, for example. I wouldn't want to bet that all
intelligent beings would understand the concept of justice, but I
wouldn't want to bet against it either.The idea of alien truth is related to Erdos's idea of God's book.
He used to describe a particularly good proof as being in God's
book, the implication being (a) that a sufficiently good proof was
more discovered than invented, and (b) that its goodness would be
universally recognized. If there's such a thing as alien truth,
then there's more in God's book than math.What should we call the search for alien truth? The obvious choice
is "philosophy." Whatever else philosophy includes, it should
probably include this. I'm fairly sure Aristotle would have thought
so. One could even make the case that the search for alien truth
is, if not an accurate description *of* philosophy, a good
definition *for* it. I.e. that it's what people who call
themselves philosophers should be doing, whether or not they currently
are. But I'm not wedded to that; doing it is what matters, not what
we call it.We may one day have something like alien life among us in the form
of AIs. And that may in turn allow us to be precise about what
truths an intelligent being would have to share with us. We might
find, for example, that it's impossible to create something we'd
consider intelligent that doesn't use Occam's razor. We might one
day even be able to prove that. But though this sort of research
would be very interesting, it's not necessary for our purposes, or
even the same field; the goal of philosophy, if we're going to call it that, would be
to see what ideas we come up with using alien truth as a target,
not to say precisely where the threshold of it is. Those two questions might one
day converge, but they'll converge from quite different directions,
and till they do, it would be too constraining to restrict ourselves
to thinking only about things we're certain would be alien truths.
Especially since this will probably be one of those areas where the
best guesses turn out to be surprisingly close to optimal. (Let's
see if that one does.)Whatever we call it, the attempt to discover alien truths would be
a worthwhile undertaking. And curiously enough, that is itself
probably an alien truth.**Thanks** to Trevor Blackwell, Greg Brockman, 
Patrick Collison, Robert Morris, and Michael Nielsen for reading drafts of this. |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'alien'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=alien&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



