What Microsoft Is this the Altair Basic of?



|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| What Microsoft Is this the Altair Basic of?February 2015One of the most valuable exercises you can try if you want to
understand startups is to look at the most successful companies and
explain why they were not as lame as they seemed when they first
launched. Because they practically all seemed lame at first. Not
just small, lame. Not just the first step up a big mountain. More
like the first step into a swamp.A Basic interpreter for the Altair? How could that ever grow into
a giant company? People sleeping on airbeds in strangers' apartments?
A web site for college students to stalk one another? A wimpy
little single-board computer for hobbyists that used a TV as a
monitor? A new search engine, when there were already about 10,
and they were all trying to de-emphasize search? These ideas didn't
just seem small. They seemed wrong. They were the kind of ideas
you could not merely ignore, but ridicule.Often the founders themselves didn't know why their ideas were
promising. They were attracted to these ideas by instinct, because
they were [living in the future](startupideas.html) and
they sensed that something was missing. But they could not have
put into words exactly how their ugly ducklings were going to grow
into big, beautiful swans.Most people's first impulse when they hear about a lame-sounding
new startup idea is to make fun of it. Even a lot of people who
should know better.When I encounter a startup with a lame-sounding idea, I ask "What
Microsoft is this the Altair Basic of?" Now it's a puzzle, and the
burden is on me to solve it. Sometimes I can't think of an answer,
especially when the idea is a made-up one. But it's remarkable how
often there does turn out to be an answer. Often it's one the
founders themselves hadn't seen yet.Intriguingly, there are sometimes multiple answers. I talked to a
startup a few days ago that could grow into 3 distinct Microsofts.
They'd probably vary in size by orders of magnitude. But you can
never predict how big a Microsoft is going to be, so in cases like
that I encourage founders to follow whichever path is most immediately
exciting to them. Their instincts got them this far. Why stop now? |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'altair'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=altair&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



