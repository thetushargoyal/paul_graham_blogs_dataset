Writing, Briefly



|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| Writing,  BrieflyMarch 2005
*(In the process
of answering an email, I accidentally wrote a tiny essay about writing.
I usually spend weeks on an essay. This one took  67 minutes—23
of writing, and  44 of rewriting.)*I think it's far more important to write well than most people
realize. Writing doesn't just communicate ideas; it generates them.
If you're bad at writing and don't like to do it, you'll miss out
on most of the ideas writing would have generated.As for how to write well, here's the short version: 
Write a bad version
1 as fast as you can; rewrite it over and over; cut ~~out~~ everything
unnecessary; write in a conversational tone; develop a nose for
bad writing, so you can see and fix it in yours; imitate writers
you like; if you can't get started, tell someone what you plan to
write about, then write down what you said; expect
80% of the ideas in an essay to happen after you start writing it,
and 50% of those you start with to be wrong; be confident enough
to cut; have friends you trust read your stuff and tell you which
bits are confusing or drag; don't (always) make detailed outlines;
mull ideas over for a few days before
writing; carry a small notebook or scrap paper with you; start writing 
when you think of the first 
sentence; if a deadline
forces you to start before that, just say the most important sentence
first; write about stuff you like; don't try to sound impressive; don't hesitate to change the topic on the fly;
use footnotes to contain digressions; use anaphora to knit
sentences together; read your essays out loud to see (a) where you stumble
over awkward phrases and (b) which bits are boring (the
paragraphs you dread reading); try to tell the
reader something new and useful; work in fairly big quanta of time;
when you restart, begin by rereading what you have so far; when you
finish, leave yourself something easy to start with; accumulate
notes for topics you plan to cover at the bottom of the file; don't
feel obliged to cover any of them; write for a reader who won't
read the essay as carefully as you do, just as pop songs are
designed to sound ok on crappy car radios; 
if you say anything mistaken, fix it immediately;
ask friends which sentence you'll regret most; go back and tone
down harsh remarks; publish stuff online, because
an audience makes you write more, and thus generate more
ideas; print out drafts instead of just looking at them
on the screen; use simple, germanic words; learn to distinguish
surprises from digressions; learn to recognize the approach of an
ending, and when one appears, grab it. |



|  |
| --- |
|  |
|  |  | [Russian Translation](http://www.livejournal.com/users/thesz/5621.html) |  |  |  | [Japanese Translation](http://d.hatena.ne.jp/doyu/20050523) |
|  |
|  |
|  |  | [Romanian Translation](http://ro.goobix.com/pg/writing44/) |  |  |  | [Spanish Translation](https://matiasandina.netlify.com/2020/01/escribiendo-en-pocas-palabras/) |
|  |
|  |
|  |  | [German Translation](http://wiki.njh.eu/Schreiben_-_kurz_gefasst) |  |  |  | [Chinese Translation](http://cs.unm.edu/~cliu/WritingBriefly_by_pg.htm) |
|  |
|  |
|  |  | [Hungarian Translation](http://idp1.blog.hu/) |  |  |  | [Catalan Translation](http://capalfar.wordpress.com/2007/10/16/traduccions-de-paul-graham-1-writing-briefly/) |
|  |
|  |
|  |  | [Danish Translation](http://baltzersen.info/articles/writing_briefly.php) |  |  |  | [Arabic Translation](https://tldrarabiccontents.blogspot.com/2020/01/blog-post_28.html) |
|  |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'writing44'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=writing44&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



