The Python Paradox



|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| The Python ParadoxAugust 2004In a recent [talk](gh.html) I said something that upset a lot of
people: that you could get smarter programmers to work on
a Python project than you could to work on a Java project.I didn't mean by this that Java programmers are dumb. I
meant that Python programmers are smart. It's a lot of
work to learn a new programming language. And people don't
learn Python because it will get them a job; they learn it
because they genuinely like to program and aren't satisfied with the languages they
already know.Which makes them exactly the kind of programmers
companies should want to hire. Hence what, for lack of a better
name, I'll call the Python paradox: if a company chooses to write
its software in a comparatively esoteric language, they'll be able 
to hire better programmers, because they'll attract only those
who cared enough to learn it. And for 
programmers the paradox is even more pronounced: the language
to learn, if you want to get a good job, is a language that
people don't learn merely to get a job.Only a few companies have been smart enough to realize this 
so far. But there is a kind of selection going on here too: they're 
exactly the companies programmers would
most like to work for. Google, for example. When they 
advertise Java programming jobs, they also want Python experience.A friend of mine who knows nearly all the widely used languages
uses Python for most of his projects. He says the main reason
is that he likes the way source code looks. That may seem
a frivolous reason to choose one language over another.
But it is not so frivolous as it sounds: when you program,
you spend more time reading code than writing it.
You push blobs of source code around the way a sculptor does
blobs of clay. So a language that makes source code ugly is
maddening to an exacting programmer, as clay full of lumps
would be to a sculptor.At the mention of ugly source code, people will of course think
of Perl. But the superficial ugliness of Perl is not the sort
I mean. Real ugliness is not harsh-looking
syntax, but having to build programs out of the wrong
concepts. Perl may look like a cartoon character swearing,
but there are 
[cases](icad.html) where it surpasses Python conceptually.So far, anyway. Both languages are of course 
[moving](hundred.html) targets. But they
share, along with Ruby (and Icon, and Joy, and J, and Lisp,
and Smalltalk) the fact that
they're created by, and used by, people who really care about
programming. And those tend to be the ones who do it well. |



|  |
| --- |
|  |
| [Turkish Translation](http://www.fazlamesai.net/modules.php?file=article&name=News&sid=2330) |  | [Japanese Translation](http://www.shiro.dreamhost.com/scheme/trans/pypar-j.html) |
|  |
|  |
| [Portuguese Translation](http://www.sounerd.com.br/index.php?option=com_content&task=view&id=191&Itemid=43) |  | [Italian Translation](http://www.invece.org/translations/pparadox.html) |
|  |
|  |
| [Polish Translation](http://www.pdembinski.konin.lm.pl/python_paradox.html) |  | [Romanian Translation](http://ro.goobix.com/pg/pypar/) |
|  |
|  |
| [Russian Translation](http://m0sia.ru/graham/pythonparadox) |  | [Spanish Translation](http://www.fduran.com/wordpress/?p=23) |
|  |
|  |
| [French Translation](http://w2.syronex.com/jmr/python-paradox) |  | [Telugu Translation](http://www.avilpage.com/2014/12/python-paradox.html) |
|  |



|  |  |
| --- | --- |
| 

---



|  |
| --- |
| 
If you liked this, you may also like
[***Hackers & Painters***](http://www.amazon.com/gp/product/0596006624).
 ||


 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'pypar'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=pypar&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



