Write Simply



|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| Write SimplyMarch 2021I try to write using ordinary words and simple sentences.That kind of writing is easier to read, and the easier something
is to read, the more deeply readers will engage with it. The less
energy they expend on your prose, the more they'll have left for
your ideas.And the further they'll read. Most readers' energy tends to flag
part way through an article or essay. If the friction of reading
is low enough, more keep going till the end.There's an Italian dish called *saltimbocca*, which means "leap
into the mouth." My goal when writing might be called *saltintesta*:
the ideas leap into your head and you barely notice the words that
got them there.It's too much to hope that writing could ever be pure ideas. You
might not even want it to be. But for most writers, most of the
time, that's the goal to aim for. The gap between most writing and
pure ideas is not filled with poetry.Plus it's more considerate to write simply. When you write in a
fancy way to impress people, you're making them do extra work just
so you can seem cool. It's like trailing a long train behind you
that readers have to carry.And remember, if you're writing in English, that a lot of your
readers won't be native English speakers. Their understanding of
ideas may be way ahead of their understanding of English. So you
can't assume that writing about a difficult topic means you can
use difficult words.Of course, fancy writing doesn't just conceal ideas. It can also
conceal the lack of them. That's why some people write that way,
to conceal the fact that they have 
 nothing to say. Whereas writing
simply keeps you honest. If you say nothing simply, it will be
obvious to everyone, including you.Simple writing also lasts better. People reading your stuff in the
future will be in much the same position as people from other
countries reading it today. The culture and the language will have
changed. It's not vain to care about that, any more than it's vain
for a woodworker to build a chair to last.Indeed, lasting is not merely an accidental quality of chairs, or
writing. It's a sign you did a good job.But although these are all real advantages of writing simply, none
of them are why I do it. The main reason I write simply is that it
offends me not to. When I write a sentence that seems too complicated,
or that uses unnecessarily intellectual words, it doesn't seem fancy
to me. It seems clumsy.There are of course times when you want to use a complicated sentence
or fancy word for effect. But you should never do it by accident.The other reason my writing ends up being simple is the way I do
it. I write the first draft fast, then spend days editing it, trying
to get everything just right. Much of this editing is cutting, and
that makes simple writing even simpler. |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'simply'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=simply&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



