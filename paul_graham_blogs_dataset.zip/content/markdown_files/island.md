The Island Test



|  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| The Island TestJuly 2006I've discovered a handy test for figuring out what you're addicted
to. Imagine you were going to spend the weekend at a friend's house
on a little island off the coast of Maine. There are no shops on
the island and you won't be able to leave while you're there. Also,
you've never been to this house before, so you can't assume it will
have more than any house might.What, besides clothes and toiletries, do you make a point of packing?
That's what you're addicted to. For example, if you find yourself
packing a bottle of vodka (just in case), you may want to stop and
think about that.For me the list is four things: books, earplugs, a notebook, and a
pen.There are other things I might bring if I thought of it, like music,
or tea, but I can live without them. I'm not so addicted to caffeine
that I wouldn't risk the house not having any tea, just for a
weekend.Quiet is another matter. I realize it seems a bit eccentric to
take earplugs on a trip to an island off the coast of Maine. If
anywhere should be quiet, that should. But what if the person in
the next room snored? What if there was a kid playing basketball?
(Thump, thump, thump... thump.) Why risk it? Earplugs are small.Sometimes I can think with noise. If I already have momentum on
some project, I can work in noisy places. I can edit an essay or
debug code in an airport. But airports are not so bad: most of the
noise is whitish. I couldn't work with the sound of a sitcom coming
through the wall, or a car in the street playing thump-thump music.And of course there's another kind of thinking, when you're starting
something new, that requires complete quiet. You never
know when this will strike. It's just as well to carry plugs.The notebook and pen are professional equipment, as it were. Though
actually there is something druglike about them, in the sense that
their main purpose is to make me feel better. I hardly ever go
back and read stuff I write down in notebooks. It's just that if
I can't write things down, worrying about remembering one idea gets
in the way of having the next. Pen and paper wick ideas.The best notebooks I've found are made by a company called Miquelrius.
I use their smallest size, which is about 2.5 x 4 in.
The secret to writing on such
narrow pages is to break words only when you run out of space, like
a Latin inscription. I use the cheapest plastic Bic ballpoints,
partly because their gluey ink doesn't seep through pages, and
partly so I don't worry about losing them.I only started carrying a notebook about three years ago. Before
that I used whatever scraps of paper I could find. But the problem
with scraps of paper is that they're not ordered. In a notebook
you can guess what a scribble means by looking at the pages
around it. In the scrap era I was constantly finding notes I'd
written years before that might say something I needed to remember,
if I could only figure out what.As for books, I know the house would probably have something to
read. On the average trip I bring four books and only read one of
them, because I find new books to read en route. Really bringing
books is insurance.I realize this dependence on books is not entirely good—that what
I need them for is distraction. The books I bring on trips are
often quite virtuous, the sort of stuff that might be assigned
reading in a college class. But I know my motives aren't virtuous.
I bring books because if the world gets boring I need to be able
to slip into another distilled by some writer. It's like eating
jam when you know you should be eating fruit.There is a point where I'll do without books. I was walking in
some steep mountains once, and decided I'd rather just think, if I
was bored, rather than carry a single unnecessary ounce. It wasn't
so bad. I found I could entertain myself by having ideas instead
of reading other people's. If you stop eating jam, fruit starts
to taste better.So maybe I'll try not bringing books on some future trip. They're
going to have to pry the plugs out of my cold, dead ears, however. |



|  |
| --- |
|  |
|  |  | [Spanish Translation](http://www.simpleoption.com/ensayo-test-isla) |  |  |  | [Japanese Translation](http://d.hatena.ne.jp/lionfan/20060721) |
|  |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'island'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=island&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



