The Need to Read



|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| The Need to ReadNovember 2022In the science fiction books I read as a kid, reading had often
been replaced by some more efficient way of acquiring knowledge.
Mysterious "tapes" would load it into one's brain like a program
being loaded into a computer.That sort of thing is unlikely to happen anytime soon. Not just
because it would be hard to build a replacement for reading, but
because even if one existed, it would be insufficient. Reading about
x doesn't just teach you about x; it also teaches you how to write.
[[1](#f1n)]Would that matter? If we replaced reading, would anyone need to be
good at writing?The reason it would matter is that writing is not just a way to
convey ideas, but also a way to have them.A good writer doesn't just think, and then write down what he
thought, as a sort of transcript. A good writer will almost always
discover new things in the process of writing. And there is, as far
as I know, no substitute for this kind of discovery. Talking about
your ideas with other people is a good way to develop them. But
even after doing this, you'll find you still discover new things
when you sit down to write. There is a kind of thinking that can
only be done by [writing](words.html).There are of course kinds of thinking that can be done without
writing. If you don't need to go too deeply into a problem, you can
solve it without writing. If you're thinking about how two pieces
of machinery should fit together, writing about it probably won't
help much. And when a problem can be described formally, you can
sometimes solve it in your head. But if you need to solve a
complicated, ill-defined problem, it will almost always help to
write about it. Which in turn means that someone who's not good at
writing will almost always be at a disadvantage in solving such
problems.You can't think well without writing well, and you can't write well
without reading well. And I mean that last "well" in both senses.
You have to be good at reading, and read good things.
[[2](#f2n)]People who just want information may find other ways to get it.
But people who want to have ideas can't afford to.**Notes**[1]
Audiobooks can give you examples of good writing, but having
them read to you doesn't teach you as much about writing as reading
them yourself.[2]
By "good at reading" I don't mean good at the mechanics of
reading. You don't have to be good at extracting words from the
page so much as extracting meaning from the words. |



|  |
| --- |
|  |
| [Japanese Translation](https://practical-scheme.net/trans/read-j.html) |  | [Chinese Translation](https://catcoding.me/p/read/) |
|  |
|  |
| [Italian Translation](https://marcotrombetti.com/leggere) |  | [French Translation](https://dorianmarie.fr/paulgraham/lire.html) |
|  |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'read'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=read&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



