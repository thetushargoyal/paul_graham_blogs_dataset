What Kate Saw in Silicon Valley 



|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| What Kate Saw in Silicon Valley  August 2009Kate Courteau is the architect who designed Y Combinator's office.
Recently we managed to recruit her to help us run YC when she's not
busy with architectural projects. Though she'd heard a lot about
YC since the beginning, the last 9 months have been a total immersion.I've been around the startup world for so long that it seems normal
to me, so I was curious to hear what had surprised her most about
it. This was her list:**1. How many startups fail.**Kate knew in principle that startups
were very risky, but she was surprised to see how constant the
threat of failure was — not just for the minnows, but even for the
famous startups whose founders came to speak at YC dinners.
**2. How much startups' ideas change.**As usual, by Demo Day about
half the startups were doing something significantly different than
they started with. We encourage that. Starting a startup is like
science in that you have to follow the truth wherever it leads. In
the rest of the world, people don't start things till they're sure
what they want to do, and once started they tend to continue on their
initial path even if it's mistaken.
**3. How little money it can take to start a startup.**In Kate's
world, everything is still physical and expensive. You can barely
renovate a bathroom for the cost of starting a startup.
**4. How scrappy founders are.**That was her actual word. I agree
with her, but till she mentioned this it never occurred to me how
little this quality is appreciated in most of the rest of the world.
It wouldn't be a compliment in most organizations to call someone
scrappy.What does it mean, exactly? It's basically the diminutive form of
belligerent. Someone who's scrappy manages to be both threatening
and undignified at the same time. Which seems to me exactly what
one would want to be, in any kind of work. If you're not threatening,
you're probably not doing anything new, and dignity is merely a
sort of plaque.
**5. How tech-saturated Silicon Valley is.**"It seems like everybody
here is in the industry." That isn't literally true, but there is
a qualitative difference between Silicon Valley and other places.
You tend to keep your voice down, because there's a good chance the
person at the next table would know some of the people you're talking
about. I never felt that in Boston. The good news is, there's
also a good chance the person at the next table could help you in
some way.
**6. That the speakers at YC were so consistent in their advice.**
Actually, I've noticed this too. I always worry the speakers will
put us in an embarrassing position by contradicting what we tell the
startups, but it happens surprisingly rarely.When I asked her what specific things she remembered speakers always
saying, she mentioned: that the way to succeed was to launch something
fast, listen to users, and then iterate; that startups required
resilience because they were always an emotional rollercoaster; and
that most VCs were sheep.I've been impressed by how consistently the speakers advocate
launching fast and iterating. That was contrarian advice 10 years
ago, but it's clearly now the established practice.
**7. How casual successful startup founders are.**Most of the famous
founders in Silicon Valley are people you'd overlook on the street.
It's not merely that they don't dress up. They don't project any
kind of aura of power either. "They're not trying to impress
anyone."Interestingly, while Kate said that she could never pick out
successful founders, she could recognize VCs, both by the way they
dressed and the way they carried themselves.
**8. How important it is for founders to have people to ask for advice.**(I swear I didn't prompt this one.) Without advice "they'd just
be sort of lost." Fortunately, there are a lot of people to help
them. There's a strong tradition within YC of helping other YC-funded
startups. But we didn't invent that idea: it's just a slightly
more concentrated form of existing Valley culture.
**9. What a solitary task startups are.**Architects are constantly
interacting face to face with other people, whereas doing a technology
startup, at least, tends to require long stretches of uninterrupted
time to work. "You could do it in a box."By inverting this list, we can get a portrait of the "normal" world.
It's populated by people who talk a lot with one another as they
work slowly but harmoniously on conservative, expensive projects
whose destinations are decided in advance, and who carefully adjust
their manner to reflect their position in the hierarchy.That's also a fairly accurate description of the past. So startup
culture may not merely be different in the way you'd expect any
subculture to be, but a leading indicator. |



|  |
| --- |
|  |
| [Japanese Translation](https://note.com/tokyojack/n/n00714ac4042a) |
|  |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'kate'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=kate&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



