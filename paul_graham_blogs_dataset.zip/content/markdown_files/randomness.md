See Randomness



|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| See RandomnessApril 2006, rev August 2009Plato quotes Socrates as saying "the unexamined life is not worth
living." Part of what he meant was that the proper role of humans is to
think, just as the proper role of anteaters is to poke their noses
into anthills.A lot of ancient philosophy had the quality — and I
don't mean this in an insulting way — of the kind of conversations
freshmen have late at night in common rooms:

What is our purpose? Well, we humans are
as conspicuously different from other animals as the anteater.
In our case the distinguishing feature is the ability to reason.
So obviously that is what we should be doing, and a human who
doesn't is doing a bad job of being human — is no better than an
animal.

Now we'd give a different answer. At least, someone Socrates's age
would. We'd ask why we even suppose we have a "purpose" in life.
We may be better adapted for some things than others; we
may be happier doing things we're adapted for; but why assume
purpose?The history of ideas
is a history of gradually discarding the assumption that it's all
about us. No, it turns out, the earth is not the center of the
universe — not even the center of the solar system. No, it turns
out, humans are not created by God in his own image; they're just
one species among many, descended not merely from apes, but from
microorganisms. Even the concept of "me" turns out to be fuzzy
around the edges if you examine it closely.The idea that we're the center of things is difficult to discard.
So difficult that there's probably room to discard more. Richard
Dawkins made another step in that direction only in the last several
decades, with the idea of the 
[selfish gene](http://en.wikipedia.org/wiki/The_Selfish_Gene). 
No, it turns
out, we're not even the protagonists: we're just the latest model
vehicle our genes have constructed to travel around in. And having
kids is our genes heading for the lifeboats. Reading
that book snapped my brain out of its previous way of thinking the
way Darwin's must have when it first appeared.(Few people can experience now what Darwin's contemporaries did
when *The Origin of Species* was first published, because everyone
now is raised either to take evolution for granted, or to regard
it as a heresy. No one encounters the idea of natural selection for
the first time as an adult.)So if you want to discover things that have been overlooked till
now, one really good place to look is in our blind spot: in our
natural, naive belief that it's all about us. And expect to encounter
ferocious opposition if you do.Conversely, if you have to choose between two theories, prefer the
one that doesn't center on you.This principle isn't only for big ideas. It works in everyday life,
too. For example, suppose you're saving a piece of cake in the fridge, and you
come home one day to find your housemate has eaten
it. Two possible theories:

a) Your housemate did it deliberately to upset you. He *knew*
you were saving that piece of cake.b) Your housemate was hungry.

I say pick b. No one knows who said "never attribute to malice what
can be explained by incompetence," but it is a powerful idea.
Its more general version is our answer to the Greeks:
Don't see purpose where there isn't.
Or better still, the positive version:
See randomness. |



|  |
| --- |
|  |
| [Korean Translation](http://owla.textcube.com/50) |
|  |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'randomness'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=randomness&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



