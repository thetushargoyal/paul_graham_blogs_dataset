Paul Graham



|  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |  |  |
| --- | --- | --- |
| 

|  |
| --- |
| 
**New:**

[Superlinear Returns](superlinear.html) |
[How to Do Great Work](greatwork.html)

 |




|  |
| --- |
| 
**Want to start a startup?** Get funded by [Y Combinator](http://ycombinator.com/apply.html).

 |





 |



|  |
| --- |
| 


© mmxxiii pg 


 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });



