Snapshot: Viaweb, June 1998



|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| Snapshot: Viaweb, June 1998January 2012A few hours before the Yahoo acquisition was announced in June 1998
I took a [snapshot of Viaweb's
site](http://ycombinator.com/viaweb). I thought it might be interesting to look at one day.The first thing one notices is is how tiny the pages are. Screens
were a lot smaller in 1998. If I remember correctly, our frontpage
used to just fit in the size window people typically used then.Browsers then (IE 6 was still 3 years in the future) had few fonts
and they weren't antialiased. If you wanted to make pages that
looked good, you had to render display text as images.You may notice a certain similarity between the Viaweb and [Y Combinator](http://ycombinator.com) logos. We did that
as an inside joke when we started YC. Considering how basic a red
circle is, it seemed surprising to me when we started Viaweb how
few other companies used one as their logo. A bit later I realized
[why](zero.html).On the [Company
page](http://www.ycombinator.com/viaweb/com.html) you'll notice a mysterious individual called John McArtyem.
Robert Morris (aka Rtm) was so publicity averse after the 
[Worm](http://en.wikipedia.org/wiki/Morris_worm) that he
didn't want his name on the site. I managed to get him to agree
to a compromise: we could use his bio but not his name. He has
since [relaxed](http://ycombinator.com/people.html) a bit
on that point.Trevor graduated at about the same time the acquisition closed, so in the
course of 4 days he went from impecunious grad student to millionaire
PhD. The culmination of my career as a writer of press releases
was one [celebrating
his graduation](http://ycombinator.com/viaweb/trevor.html), illustrated with a drawing I did of him during
a meeting.(Trevor also appears as [Trevino
Bagwell](http://ycombinator.com/viaweb/tlbwebdesign.html) in our directory of web designers merchants could hire
to build stores for them. We inserted him as a ringer in case some
competitor tried to spam our web designers. We assumed his logo
would deter any actual customers, but it did not.)Back in the 90s, to get users you had to get mentioned in magazines
and newspapers. There were not the same ways to get found online
that there are today. So we used to pay a [PR
firm](submarine.html) $16,000 a month to get us mentioned in the press. Fortunately
reporters [liked
us](http://ycombinator.com/viaweb/presquot.html).In our [advice about
getting traffic from search engines](http://ycombinator.com/viaweb/se.html) (I don't think the term SEO
had been coined yet), we say there are only 7 that matter: Yahoo,
AltaVista, Excite, WebCrawler, InfoSeek, Lycos, and HotBot. Notice
anything missing? Google was incorporated that September.We supported online transactions via a company called 
[Cybercash](http://en.wikipedia.org/wiki/CyberCash,_Inc.),
since if we lacked that feature we'd have gotten beaten up in product
comparisons. But Cybercash was so bad and most stores' order volumes
were so low that it was better if merchants processed orders like phone orders. We had a page in our site trying to [talk merchants
out of doing real time authorizations](http://www.ycombinator.com/viaweb/cybercash.html).The whole site was organized like a funnel, directing people to the
[test drive](http://ycombinator.com/viaweb/tesdriv.html).
It was a novel thing to be able to try out software online. We put
cgi-bin in our dynamic urls to fool competitors about how our
software worked.We had some [well
known users](http://ycombinator.com/viaweb/us.html). Needless to say, Frederick's of Hollywood got the
most traffic. We charged a flat fee of $300/month for big stores,
so it was a little alarming to have users who got lots of traffic.
I once calculated how much Frederick's was costing us in bandwidth,
and it was about $300/month.Since we hosted all the stores, which together were getting just
over 10 million page views per month in June 1998, we consumed what
at the time seemed a lot of bandwidth. We had 2 T1s (3 Mb/sec)
coming into our offices. In those days there was no AWS. Even
colocating servers seemed too risky, considering how often things
went wrong with them. So we had our servers in our offices. Or
more precisely, in Trevor's office. In return for the unique
privilege of sharing his office with no other humans, he had to
share it with 6 shrieking tower servers. His office was nicknamed
the Hot Tub on account of the heat they generated. Most days his
stack of window air conditioners could keep up.For describing pages, we had a template language called [RTML](http://ycombinator.com/viaweb/rtml.html), which
supposedly stood for something, but which in fact I named after
Rtm. RTML was Common Lisp augmented by some macros and libraries,
and concealed under a structure editor that made it look like it
had syntax.Since we did continuous releases, our software didn't actually have
versions. But in those days the trade press expected versions, so
we made them up. If we wanted to get lots of attention, we made
the version number [an
integer](http://www.ycombinator.com/viaweb/rel4.html). That "version 4.0" icon was generated by our own
button generator, incidentally. The whole Viaweb site was made
with our software, even though it wasn't an online store, because
we wanted to experience what our users did.At the end of 1997, we released a general purpose shopping search
engine called [Shopfind](http://ycombinator.com/viaweb/shoprel.html). It
was pretty advanced for the time. It had a programmable crawler
that could crawl most of the different stores online and pick out
the products. |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'vw'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=vw&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



