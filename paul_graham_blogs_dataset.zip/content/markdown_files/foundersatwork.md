Learning from Founders



|  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| Learning from FoundersJanuary 2007*(Foreword to Jessica Livingston's 
[Founders at Work](http://www.amazon.com/gp/product/1590597141).)*Apparently sprinters reach their highest speed right out of the
blocks, and spend the rest of the race slowing down. The winners
slow down the least. It's that way with most startups too. The
earliest phase is usually the most productive. That's when they
have the really big ideas. Imagine what Apple was like when 100%
of its employees were either Steve Jobs or Steve Wozniak.The striking thing about this phase is that it's completely different
from most people's idea of what business is like. If you looked
in people's heads (or stock photo collections) for images representing
"business," you'd get images of people dressed up in suits, groups
sitting around conference tables looking serious, Powerpoint
presentations, people producing thick reports for one another to
read. Early stage startups are the exact opposite of this. And
yet they're probably the most productive part of the whole economy.Why the disconnect? I think there's a general principle at work
here: the less energy people expend on performance, the more they
expend on appearances to compensate. More often than not the energy
they expend on seeming impressive makes their actual performance
worse. A few years ago I read an article in which a car magazine
modified the "sports" model of some production car to get the fastest
possible standing quarter mile. You know how they did it? They
cut off all the crap the manufacturer had bolted onto the car to
make it *look* fast.Business is broken the same way that car was. The effort that goes
into looking productive is not merely wasted, but actually makes
organizations less productive. Suits, for example. Suits do not
help people to think better. I bet most executives at big companies
do their best thinking when they wake up on Sunday morning and go
downstairs in their bathrobe to make a cup of coffee. That's when
you have ideas. Just imagine what a company would be like if people
could think that well at work. People do in startups, at least
some of the time. (Half the time you're in a panic because your
servers are on fire, but the other half you're thinking as deeply
as most people only get to sitting alone on a Sunday morning.)Ditto for most of the other differences between startups and what
passes for productivity in big companies. And yet conventional
ideas of professionalism have such an iron grip on our minds that
even startup founders are affected by them. In our startup, when
outsiders came to visit we tried hard to seem "professional." We'd
clean up our offices, wear better clothes, try to arrange that a
lot of people were there during conventional office hours. In fact,
programming didn't get done by well-dressed people at clean desks
during office hours. It got done by badly dressed people (I was
notorious for programmming wearing just a towel) in offices strewn
with junk at 2 in the morning. But no visitor would understand
that. Not even investors, who are supposed to be able to recognize
real productivity when they see it. Even we were affected by the
conventional wisdom. We thought of ourselves as impostors, succeeding
despite being totally unprofessional. It was as if we'd created a
Formula 1 car but felt sheepish because it didn't look like a car
was supposed to look.In the car world, there are at least some people who know that a
high performance car looks like a Formula 1 racecar, not a sedan
with giant rims and a fake spoiler bolted to the trunk. Why not
in business? Probably because startups are so small. The really
dramatic growth happens when a startup only has three or four people,
so only three or four people see that, whereas tens of thousands
see business as it's practiced by Boeing or Philip Morris.This book can help fix that problem, by showing everyone what, till
now, only a handful people got to see: what happens in the first
year of a startup. This is what real productivity looks like. This
is the Formula 1 racecar. It looks weird, but it goes fast.Of course, big companies won't be able to do everything these
startups do. In big companies there's always going to be more
politics, and less scope for individual decisions. But seeing what
startups are really like will at least show other organizations
what to aim for. The time may soon be coming when instead of
startups trying to seem more corporate, corporations will try to
seem more like startups. That would be a good thing.
[Japanese
Translation](http://www.aoky.net/articles/paul_graham/foundersatwork.htm)


---

 |



|  |
| --- |
|  |
|  |  | **Founders at Work**There can't be more than a couple thousand
people who know first-hand what happens in the first month of a
successful startup. Jessica Livingston got them to tell us. 
So despite the interview format, this is
really a how-to book. It is probably the single most valuable 
book a startup founder could read. |
|  |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'foundersatwork'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=foundersatwork&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



