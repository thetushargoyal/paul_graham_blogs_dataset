General and Surprising



|  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| General and SurprisingSeptember 2017The most valuable insights are both general and surprising. 
F = ma for example. But general and surprising is a hard
combination to achieve. That territory tends to be picked
clean, precisely because those insights are so valuable.Ordinarily, the best that people can do is one without the
other: either surprising without being general (e.g.
gossip), or general without being surprising (e.g.
platitudes).Where things get interesting is the moderately valuable
insights. You get those from small additions of whichever
quality was missing. The more common case is a small
addition of generality: a piece of gossip that's more than
just gossip, because it teaches something interesting about
the world. But another less common approach is to focus on
the most general ideas and see if you can find something new
to say about them. Because these start out so general, you
only need a small delta of novelty to produce a useful
insight.A small delta of novelty is all you'll be able to get most
of the time. Which means if you take this route, your ideas
will seem a lot like ones that already exist. Sometimes
you'll find you've merely rediscovered an idea that did
already exist. But don't be discouraged. Remember the huge
multiplier that kicks in when you do manage to think of
something even a little new.Corollary: the more general the ideas you're talking about,
the less you should worry about repeating yourself. If you
write enough, it's inevitable you will. Your brain is much
the same from year to year and so are the stimuli that hit
it. I feel slightly bad when I find I've said something
close to what I've said before, as if I were plagiarizing
myself. But rationally one shouldn't. You won't say
something exactly the same way the second time, and that
variation increases the chance you'll get that tiny but
critical delta of novelty.And of course, ideas beget ideas. (That sounds 
[familiar](ecw.html).)
An idea with a small amount of novelty could lead to one
with more. But only if you keep going. So it's doubly
important not to let yourself be discouraged by people who
say there's not much new about something you've discovered.
"Not much new" is a real achievement when you're talking
about the most general ideas. It's not true that there's nothing new under the sun. There
are some domains where there's almost nothing new. But
there's a big difference between nothing and almost nothing,
when it's multiplied by the area under the sun.
**Thanks** to Sam Altman, Patrick Collison, and Jessica
Livingston for reading drafts of this. |



|  |
| --- |
|  |
| [Japanese Translation](https://note.com/tokyojack/n/nbdc4bb355499) |
|  |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'sun'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=sun&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



