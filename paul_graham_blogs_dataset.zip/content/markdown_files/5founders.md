Five Founders



|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| Five FoundersApril 2009*Inc* recently asked me who I thought were the 5 most
interesting startup founders of the last 30 years. How do
you decide who's the most interesting? The best test seemed
to be influence: who are the 5
who've influenced me most? Who do I use as examples when I'm
talking to companies we fund? Who do I find myself quoting?**1. Steve Jobs**I'd guess Steve is the most influential founder not just for me but
for most people you could ask. A lot of startup culture is Apple
culture. He was the original young founder. And while the concept
of "insanely great" already existed in the arts, it was a novel
idea to introduce into a company in the 1980s.More remarkable still, he's stayed interesting for 30 years. People
await new Apple products the way they'd await new books by a popular
novelist. Steve may not literally design them, but they wouldn't
happen if he weren't CEO.Steve is clever and driven, but so are a lot of people in the Valley.
What makes him unique is his 
[sense of 
design](taste.html). Before him, most
companies treated design as a frivolous extra. Apple's competitors
now know better.**2. TJ Rodgers**TJ Rodgers isn't as famous as Steve Jobs, but he may be the best
writer among Silicon Valley CEOs. I've probably learned more from
him about the startup way of thinking than from anyone else. Not
so much from specific things he's written as by reconstructing the
mind that produced them: brutally candid; aggressively garbage-collecting
outdated ideas; and yet driven by pragmatism rather than ideology.The first essay of his that I read was so electrifying that I
remember exactly where I was at the time. It was 
[High
Technology Innovation: Free Markets or Government Subsidies?](http://www.cypress.com/?rID=34993) and
I was downstairs in the Harvard Square T Station. It felt as if
someone had flipped on a light switch inside my head.**3. Larry & Sergey**I'm sorry to treat Larry and Sergey as one person. I've always
thought that was unfair to them. But it does seem as if Google was a
collaboration.Before Google, companies in Silicon Valley already knew it was
important to have the best hackers. So they claimed, at least.
But Google pushed this idea further than anyone had before. Their
hypothesis seems to have been that, in the initial stages at least,
*all* you need is good hackers: if you hire all the smartest people
and put them to work on a problem where their success can be measured,
you win. All the other stuff—which includes all the stuff that
business schools think business consists of—you can figure out
along the way. The results won't be perfect, but they'll be optimal.
If this was their hypothesis, it's now been verified experimentally.**4. Paul Buchheit**Few know this, but one person, Paul Buchheit, is responsible for
three of the best things Google has done. He was the original
author of GMail, which is the most impressive thing Google has after
search. He also wrote the first prototype of AdSense, and was the
author of Google's mantra "Don't be evil."PB made a point in a talk once that I now mention to every startup
we fund: that it's better, initially, to make a small number of
users really love you than a large number kind of like you. If I
could tell startups only 
[ten sentences](13sentences.html), 
this would be one of them.Now he's cofounder of a startup called Friendfeed. It's only a
year old, but already everyone in the Valley is watching them.
Someone responsible for three of the biggest ideas at Google is
going to come up with more.**5. Sam Altman**I was told I shouldn't mention founders of YC-funded companies in
this list. But Sam Altman can't be stopped by such flimsy rules.
If he wants to be on this list, he's going to be.Honestly, Sam is, along with Steve Jobs, the founder I refer to
most when I'm advising startups. On questions of design, I ask
"What would Steve do?" but on questions of strategy or ambition I
ask "What would Sama do?"What I learned from meeting Sama is that the doctrine of the elect
applies to startups. It applies way less than most people think:
startup investing does not consist of trying to pick winners the
way you might in a horse race. But there are a few people with
such force of will that they're going to get whatever they want. |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = '5founders'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=5founders&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



