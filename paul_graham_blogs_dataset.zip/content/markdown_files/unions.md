An Alternative Theory of Unions



|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| An Alternative Theory of UnionsMay 2007People who worry about the increasing gap between rich and poor
generally look back on the mid twentieth century as a golden age.
In those days we had a large number of high-paying union manufacturing
jobs that boosted the median income. I wouldn't quite call the
high-paying union job a myth, but I think people who dwell on it
are reading too much into it.Oddly enough, it was working with startups that made me realize
where the high-paying union job came from. In a rapidly growing
market, you don't worry too much about efficiency. It's more
important to grow fast. If there's some mundane problem getting
in your way, and there's a simple solution that's somewhat expensive,
just take it and get on with more important things. EBay didn't
win by paying less for servers than their competitors.Difficult though it may be to imagine now, manufacturing was a
growth industry in the mid twentieth century. This was an era when
small firms making everything from cars to candy were getting
consolidated into a new kind of corporation with national reach and
huge economies of scale. You had to grow fast or die. Workers
were for these companies what servers are for an Internet startup.
A reliable supply was more important than low cost.If you looked in the head of a 1950s auto executive, the attitude
must have been: sure, give 'em whatever they ask for, so long as
the new model isn't delayed.In other words, those workers were not paid what their work was
worth. Circumstances being what they were, companies would have
been stupid to insist on paying them so little.If you want a less controversial example of this phenomenon, ask
anyone who worked as a consultant building web sites during the
Internet Bubble. In the late nineties you could get paid huge sums
of money for building the most trivial things. And yet does anyone
who was there have any expectation those days will ever return? I
doubt it. Surely everyone realizes that was just a temporary
aberration.The era of labor unions seems to have been the same kind of aberration, 
just spread
over a longer period, and mixed together with a lot of ideology
that prevents people from viewing it with as cold an eye as they
would something like consulting during the Bubble.Basically, unions were just Razorfish.People who think the labor movement was the creation of heroic union
organizers have a problem to explain: why are unions shrinking now?
The best they can do is fall back on the default explanation of
people living in fallen civilizations. Our ancestors were giants.
The workers of the early twentieth century must have had a moral
courage that's lacking today.In fact there's a simpler explanation. The early twentieth century
was just a fast-growing startup overpaying for infrastructure. And
we in the present are not a fallen people, who have abandoned
whatever mysterious high-minded principles produced the high-paying
union job. We simply live in a time when the fast-growing companies
overspend on different things. |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'unions'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=unions&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



