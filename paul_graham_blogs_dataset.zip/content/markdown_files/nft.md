An NFT That Saves Lives



|  |  |  |  |  |
| --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| An NFT That Saves LivesMay 2021[Noora Health](https://www.noorahealth.org/), a nonprofit I've 
supported for years, just launched
a new NFT. It has a dramatic name, [Save Thousands of Lives](http://bit.ly/NooraNFT),
because that's what the proceeds will do.Noora has been saving lives for 7 years. They run programs in
hospitals in South Asia to teach new mothers how to take care of
their babies once they get home. They're in 165 hospitals now. And
because they know the numbers before and after they start at a new
hospital, they can measure the impact they have. It is massive.
For every 1000 live births, they save 9 babies.This number comes from a [study](http://bit.ly/NFT-research)
of 133,733 families at 28 different
hospitals that Noora conducted in collaboration with the Better
Birth team at Ariadne Labs, a joint center for health systems
innovation at Brigham and Womens Hospital and Harvard T.H. Chan
School of Public Health.Noora is so effective that even if you measure their costs in the
most conservative way, by dividing their entire budget by the number
of lives saved, the cost of saving a life is the lowest I've seen.
$1,235.For this NFT, they're going to issue a public report tracking how
this specific tranche of money is spent, and estimating the number
of lives saved as a result.NFTs are a new territory, and this way of using them is especially
new, but I'm excited about its potential. And I'm excited to see
what happens with this particular auction, because unlike an NFT
representing something that has already happened,
this NFT gets better as the price gets higher.The reserve price was about $2.5 million, because that's what it
takes for the name to be accurate: that's what it costs to save
2000 lives. But the higher the price of this NFT goes, the more
lives will be saved. What a sentence to be able to write. |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'nft'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=nft&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



