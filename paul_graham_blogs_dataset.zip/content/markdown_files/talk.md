Write Like You Talk



|  |  |  |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | 

|  |
| --- |
| Write Like You TalkOctober 2015Here's a simple trick for getting more people to read what you
write: write in spoken language.Something comes over most people when they start writing. They write
in a different language than they'd use if they were talking to a
friend. The sentence structure and even the words are different.
No one uses "pen" as a verb in spoken English. You'd feel like an
idiot using "pen" instead of "write" in a conversation with a friend.The last straw for me was a sentence I read a couple days ago:

 The mercurial Spaniard himself declared: "After Altamira, all is
 decadence."

It's from Neil Oliver's *A History of Ancient Britain*. I feel bad
making an example of this book, because it's no worse than lots of
others. But just imagine calling Picasso "the mercurial Spaniard" when
talking to a friend. Even one
sentence of this would raise eyebrows in conversation. And yet
people write whole books of it.Ok, so written and spoken language are different. Does that make
written language worse?If you want people to read and understand what you write, yes.
Written language is more complex, which makes it more work to read.
It's also more formal and distant, which gives the reader's attention
permission to drift. But perhaps worst of all, the complex sentences
and fancy words give you, the writer, the false impression that
you're saying more than you actually are.You don't need complex sentences to express complex ideas. When
specialists in some abstruse topic talk to one another about ideas
in their field, they don't use sentences any more complex than they
do when talking about what to have for lunch. They use different
words, certainly. But even those they use no more than necessary.
And in my experience, the harder the subject, the more informally
experts speak. Partly, I think, because they have less to prove,
and partly because the harder the ideas you're talking about, the
less you can afford to let language get in the way.Informal language is the athletic clothing of ideas.I'm not saying spoken language always works best. Poetry is as much
music as text, so you can say things you wouldn't say in conversation.
And there are a handful of writers who can get away with using fancy
language in prose. And then of course there are cases where writers
don't want to make it easy to understand what they're saying—in
corporate announcements of bad news, for example, or at the more
[bogus](https://scholar.google.com/scholar?hl=en&as_sdt=1,5&q=transgression+narrative+postmodern+gender) end of the humanities. But for nearly everyone else, spoken
language is better.It seems to be hard for most people to write in spoken language.
So perhaps the best solution is to write your first draft the way
you usually would, then afterward look at each sentence and ask "Is
this the way I'd say this if I were talking to a friend?" If it
isn't, imagine what you would say, and use that instead. After a
while this filter will start to operate as you write. When you write
something you wouldn't say, you'll hear the clank as it hits the
page.Before I publish a new essay, I read it out loud and fix everything
that doesn't sound like conversation. I even fix bits that are
phonetically awkward; I don't know if that's necessary, but it
doesn't cost much.This trick may not always be enough. I've seen writing so far
removed from spoken language that it couldn't be fixed sentence by
sentence. For cases like that there's a more drastic solution.
After writing the first draft, try explaining to a friend what you
just wrote. Then replace the draft with what you said to your friend.People often tell me how much my essays sound like me talking.
The fact that this seems worthy of comment shows how rarely people
manage to write in spoken language. Otherwise everyone's writing
would sound like them talking.If you simply manage to write in spoken language, you'll be ahead
of 95% of writers. And it's so easy to do: just don't let a sentence
through unless it's the way you'd say it to a friend.**Thanks** to Patrick Collison and Jessica Livingston for reading drafts of this. |



|  |
| --- |
|  |
| [Japanese Translation](https://note.com/tokyojack/n/n9a13ac4cd47d) |  | [Arabic Translation](https://tldrarabiccontents.blogspot.com/2020/01/blog-post_30.html) |
|  |



|  |
| --- |
| 

---

 |

 |



csell\_env = 'ue1';
 var storeCheckoutDomain = 'order.store.turbify.net';


 function toOSTN(node){
 if(node.hasAttributes()){
 for (const attr of node.attributes) {
 node.setAttribute(attr.name,attr.value.replace(/(us-dc1-order|us-dc2-order|order)\.(store|stores)\.([a-z0-9-]+)\.(net|com)/g, storeCheckoutDomain));
 }
 }
 };
 document.addEventListener('readystatechange', event => {
 if(typeof storeCheckoutDomain != 'undefined' && storeCheckoutDomain != "order.store.turbify.net"){
 if (event.target.readyState === "interactive") {
 fromOSYN = document.getElementsByTagName('form');
 for (let i = 0; i < fromOSYN.length; i++) {
 toOSTN(fromOSYN[i]);
 }
 }
 }
 });


// Begin Store Generated Code
   


// Begin Store Generated Code
 csell\_page\_data = {}; csell\_page\_rec\_data = []; ts='TOK\_STORE\_ID';


// Begin Store Generated Code
function csell\_GLOBAL\_INIT\_TAG() { var csell\_token\_map = {}; csell\_token\_map['TOK\_SPACEID'] = '2022276099'; csell\_token\_map['TOK\_URL'] = ''; csell\_token\_map['TOK\_BEACON\_TYPE'] = 'prod'; csell\_token\_map['TOK\_IS\_ORDERABLE'] = '2'; csell\_token\_map['TOK\_RAND\_KEY'] = 't'; csell\_token\_map['TOK\_STORE\_ID'] = 'paulgraham'; csell\_token\_map['TOK\_ITEM\_ID\_LIST'] = 'talk'; csell\_token\_map['TOK\_ORDER\_HOST'] = 'order.store.turbify.net'; c = csell\_page\_data; var x = (typeof storeCheckoutDomain == 'string')?storeCheckoutDomain:'order.store.turbify.net'; var t = csell\_token\_map; c['s'] = t['TOK\_SPACEID']; c['url'] = t['TOK\_URL']; c['si'] = t[ts]; c['ii'] = t['TOK\_ITEM\_ID\_LIST']; c['bt'] = t['TOK\_BEACON\_TYPE']; c['rnd'] = t['TOK\_RAND\_KEY']; c['io'] = t['TOK\_IS\_ORDERABLE']; YStore.addItemUrl = 'http%s://'+x+'/'+t[ts]+'/ymix/MetaController.html?eventName.addEvent&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_itemId=%s&cartDS.shoppingcart\_ROW0\_m\_orderItemVector\_ROW0\_m\_quantity=1&ysco\_key\_cs\_item=1&sectionId=ysco.cart&ysco\_key\_store\_id='+t[ts]; } 


// Begin Store Generated Code
function csell\_REC\_VIEW\_TAG() { var env = (typeof csell\_env == 'string')?csell\_env:'prod'; var p = csell\_page\_data; var a = '/sid='+p['si']+'/io='+p['io']+'/ii='+p['ii']+'/bt='+p['bt']+'-view'+'/en='+env; var r=Math.random(); YStore.CrossSellBeacon.renderBeaconWithRecData(p['url']+'/p/s='+p['s']+'/'+p['rnd']+'='+r+a); } 


// Begin Store Generated Code
var csell\_token\_map = {}; csell\_token\_map['TOK\_PAGE'] = 'p'; csell\_token\_map['TOK\_CURR\_SYM'] = '$'; csell\_token\_map['TOK\_WS\_URL'] = 'https://paulgraham./cs/recommend?itemids=talk&location=p'; csell\_token\_map['TOK\_SHOW\_CS\_RECS'] = 'false'; var t = csell\_token\_map; csell\_GLOBAL\_INIT\_TAG(); YStore.page = t['TOK\_PAGE']; YStore.currencySymbol = t['TOK\_CURR\_SYM']; YStore.crossSellUrl = t['TOK\_WS\_URL']; YStore.showCSRecs = t['TOK\_SHOW\_CS\_RECS'];   



